class Colaborador extends Pessoa {
    private String nivel;

    public Colaborador(String nome, String email, String telefone, String nivel) {
        super(nome, email, telefone,nivel);
        this.nivel = nivel;
    }

    public String getNivel() {
        return nivel;
    }

    public void setNivel(String nivel) {
        this.nivel = nivel;
    }

}


   