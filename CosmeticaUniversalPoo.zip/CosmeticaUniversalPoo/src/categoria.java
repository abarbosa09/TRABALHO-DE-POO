public class categoria {
    private String tipo;
    private Produto produto;
    private int quantidade;
    private String descricao;
    private String validade;

    public categoria(String tipo) {
        this.tipo = tipo;
        this.produto = produto;
        this.quantidade = quantidade;
        this.descricao = descricao;
        this.validade = validade;
    }

    // Getters e Setters
    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getValidade() {
        return validade;
    }

    public void setValidade(String validade) {
        this.validade = validade;
    }
}
