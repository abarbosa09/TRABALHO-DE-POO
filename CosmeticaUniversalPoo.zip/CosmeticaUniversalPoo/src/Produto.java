public class Produto {
    private int quantidade;
    private double preco;
    private String categoria;
    private String nome;

    public Produto(int quantidade, double preco, String categoria, String nome) {
        this.quantidade = quantidade;
        this.preco = preco;
        this.categoria = categoria;
        this.nome = nome;
    }
    public String toString() {
        return nome;  // Para exibir o nome do produto no JComboBox
    }

    // Getters e Setters
    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setCategoria(categoria categoria) {

    }
}
