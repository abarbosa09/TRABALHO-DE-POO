public class Promocao {
    private String tipo;
    private String produto;
    private double numeroDoPedido;

    public Promocao(String tipo, String produto, double numeroDoPedido) {
        this.tipo = tipo;
        this.produto = produto;
        this.numeroDoPedido = numeroDoPedido;
    }

    public String getTipo() {
        return tipo;
    }

    public String getProduto() {
        return produto;
    }

    public double getNumeroDoPedido() {
        return numeroDoPedido;
    }
}
