import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class Main {
    private static List<Produto> produtos = new ArrayList<>();
    private static List<Cliente> clientes = new ArrayList<>();
    private static List<Colaborador> colaboradores = new ArrayList<>();
    private static List<Fornecedor> fornecedores = new ArrayList<>();
    private static List<FormaPagamento> formasPagamento = new ArrayList<>();
    private static List<Promocao> promocoes = new ArrayList<>();
    private static List<Estoque> estoques = new ArrayList<>();
    private static List<categoria> categorias = new ArrayList<>();
    private static List<Pedido> pedidos = new ArrayList<>();

    //LOGIN E SENHA
    public static void main(String[] args) {

        JFrame loginFrame = new JFrame("Login");
        loginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        loginFrame.setSize(300, 150);
        loginFrame.setLayout(new GridLayout(3, 2));

        JLabel lblUsuario = new JLabel("Usuário:");
        JTextField txtUsuario = new JTextField();
        JLabel lblSenha = new JLabel("Senha:");
        JPasswordField txtSenha = new JPasswordField();
        JButton btnLogin = new JButton("Entrar");
        loginFrame.setLocationRelativeTo(null); // Centralizar a tela
        loginFrame.setVisible(true);

        loginFrame.add(lblUsuario);
        loginFrame.add(txtUsuario);
        loginFrame.add(lblSenha);
        loginFrame.add(txtSenha);
        loginFrame.add(new JLabel());
        loginFrame.add(btnLogin);

        loginFrame.setVisible(true);

        btnLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String usuario = txtUsuario.getText();
                String senha = new String(txtSenha.getPassword());

                //Qualquer usuário e senha são aceitos(em caso de usabilidade tem que colocar uma trava de segurança)
                if (!usuario.isEmpty() && !senha.isEmpty()) {
                    loginFrame.dispose();
                    iniciarAplicacao();
                } else {
                    JOptionPane.showMessageDialog(loginFrame, "Usuário ou senha inválidos!", "Erro", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }

    private static void iniciarAplicacao() {
        JFrame mainFrame = new JFrame("Cosmética Universal");
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setSize(400, 400);
        mainFrame.setLayout(new GridLayout(10, 1));
        mainFrame.setLocationRelativeTo(null); // Centraliza a tela
        mainFrame.setVisible(true);

        //TELA INICIAL PARA CADASTROS
        JButton btnFornecedor = new JButton("Cadastrar Fornecedor");
        JButton btnProduto = new JButton("Cadastrar Produto");
        JButton btnEstoque = new JButton("Cadastrar Estoque");
        JButton btnCategoria = new JButton("Cadastrar Categoria");
        JButton btnPromocao = new JButton("Cadastrar Promoção");
        JButton btnFormaPagamento = new JButton("Cadastrar Forma de Pagamento");
        JButton btnColaborador = new JButton("Cadastrar Colaborador");
        JButton btnCliente = new JButton("Cadastrar Cliente");
        JButton btnPedido = new JButton("Criar Pedido");
        JButton btnMostrarPedidos = new JButton("Mostrar Pedidos");


        mainFrame.add(btnFornecedor);
        mainFrame.add(btnProduto);
        mainFrame.add(btnEstoque);
        mainFrame.add(btnCategoria);
        mainFrame.add(btnPromocao);
        mainFrame.add(btnFormaPagamento);
        mainFrame.add(btnColaborador);
        mainFrame.add(btnCliente);
        mainFrame.add(btnPedido);
        mainFrame.add(btnMostrarPedidos);

        //CADASTRO DE FORNECEDOR
        btnFornecedor.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frameFornecedor = new JFrame("Cadastro de Fornecedor");
                frameFornecedor.setSize(300, 400);
                frameFornecedor.setLayout(new GridLayout(5, 2));

                //USUÁRIO INSERE AS INFORMAÇÕES
                JLabel lblNomeFornecedor = new JLabel("Nome do Fornecedor:");
                JTextField txtNomeFornecedor = new JTextField();
                JLabel lblEmailFornecedor = new JLabel("Email do Fornecedor:");
                JTextField txtEmailFornecedor = new JTextField();
                JLabel lblTelefoneFornecedor = new JLabel("Telefone do Fornecedor:");
                JTextField txtTelefoneFornecedor = new JTextField();
                JLabel lblCnpjFornecedor = new JLabel("CNPJ do Fornecedor:");
                JTextField txtCNPJFornecedor = new JTextField();
                JButton btnSalvarFornecedor = new JButton("Salvar Fornecedor");

                frameFornecedor.add(lblNomeFornecedor);
                frameFornecedor.add(txtNomeFornecedor);
                frameFornecedor.add(lblEmailFornecedor);
                frameFornecedor.add(txtEmailFornecedor);
                frameFornecedor.add(lblTelefoneFornecedor);
                frameFornecedor.add(txtTelefoneFornecedor);
                frameFornecedor.add(lblCnpjFornecedor);
                frameFornecedor.add(txtCNPJFornecedor);
                frameFornecedor.add(btnSalvarFornecedor);

                //SALVA O CADASTRO DO FORNECEDOR FEITO PELO USUARIO
                btnSalvarFornecedor.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        String nomeFornecedor = txtNomeFornecedor.getText();
                        String emailFornecedor = txtEmailFornecedor.getText();
                        String TelefoneFornecedor = txtTelefoneFornecedor.getText();
                        String CNPJFornecedor = txtCNPJFornecedor.getText();
                        Fornecedor fornecedor = new Fornecedor(nomeFornecedor, emailFornecedor, TelefoneFornecedor,CNPJFornecedor);
                        fornecedores.add(fornecedor);

                        //EXIBE O FORNECEDOR CADASTRADO
                        JOptionPane.showMessageDialog(frameFornecedor, "Fornecedor cadastrado com sucesso!\n" +
                                "Nome: " + fornecedor.getNome() + "\n" +
                                "Email: " + fornecedor.getEmail() + "\n" +
                                "Telefone: " + fornecedor.getTelefone() +"\n" +
                                "CNPJ: " + fornecedor.getCnpj());

                        frameFornecedor.dispose();
                    }
                });
                frameFornecedor.setLocationRelativeTo(null);
                frameFornecedor.setVisible(true);
            }
        });

        //CADASTRO DO PRODUTO PELO USUARIO
        btnProduto.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frameProduto = new JFrame("Cadastro de Produto");
                frameProduto.setSize(300, 400);
                frameProduto.setLayout(new GridLayout(5, 2));

                //USUÁRIO INSERE AS INFORMAÇÕES
                JLabel lblNomeProduto = new JLabel("Nome do Produto:");
                JTextField txtNomeProduto = new JTextField();
                JLabel lblCategoriaProduto = new JLabel("Categoria do Produto:");
                JTextField txtCategoriaProduto = new JTextField();
                JLabel lblQuantidadeProduto = new JLabel("Quantidade do Produto (g/L):");
                JTextField txtQuantidadeProduto = new JTextField();
                JLabel lblPrecoProduto = new JLabel("Preço do Produto:");
                JTextField txtPrecoProduto = new JTextField();
                JButton btnSalvarProduto = new JButton("Salvar Produto");

                frameProduto.add(lblNomeProduto);
                frameProduto.add(txtNomeProduto);
                frameProduto.add(lblCategoriaProduto);
                frameProduto.add(txtCategoriaProduto);
                frameProduto.add(lblQuantidadeProduto);
                frameProduto.add(txtQuantidadeProduto);
                frameProduto.add(lblPrecoProduto);
                frameProduto.add(txtPrecoProduto);
                frameProduto.add(btnSalvarProduto);

                //SALVAR PRODUTO
                btnSalvarProduto.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        String nomeProduto = txtNomeProduto.getText();
                        String categoriaProduto = txtCategoriaProduto.getText();
                        int quantidadeProduto = Integer.parseInt(txtQuantidadeProduto.getText());
                        double precoProduto = Double.parseDouble(txtPrecoProduto.getText());
                        Produto produto = new Produto(quantidadeProduto, precoProduto, categoriaProduto, nomeProduto);
                        produtos.add(produto);

                        // EXIBE O PRODUTO CADASTRADO
                        JOptionPane.showMessageDialog(frameProduto, "Produto cadastrado com sucesso!\n" +
                                "Nome: " + produto.getNome() + "\n" +
                                "Categoria: " + produto.getCategoria() + "\n" +
                                "Quantidade: " + produto.getQuantidade() + "\n" +
                                "Preço: " + produto.getPreco());
                        frameProduto.dispose();
                    }
                });
                frameProduto.setLocationRelativeTo(null);
                frameProduto.setVisible(true);
            }
        });

        //CADASTRO DO ESTOQUE PELO USUARIO
        btnEstoque.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frameEstoque = new JFrame("Cadastro de Estoque");
                frameEstoque.setSize(500, 400);
                frameEstoque.setLayout(new GridLayout(5, 2));

                //USUÁRIO INSERE AS INFORMAÇÕES
                JLabel lblTipoEstoque = new JLabel("Tipo de estoque:");
                JTextField txtTipoEstoque = new JTextField();
                JLabel lblQuantidadeEstoque = new JLabel("Quantidade de produtos em estoque:");
                JTextField txtQuantidadeEstoque = new JTextField();
                JLabel lblLocalizacaoEstoque = new JLabel("Localização No Estoque:");
                JTextField txtLocalizacaoEstoque = new JTextField();
                JLabel lblResponsavelEstoque = new JLabel("Responsável do Estoque :");
                JTextField txtResponsavelEstoque = new JTextField();
                JButton btnSalvarEstoque = new JButton("Salvar Estoque");

                frameEstoque.add(lblTipoEstoque);
                frameEstoque.add(txtTipoEstoque);
                frameEstoque.add(lblQuantidadeEstoque);
                frameEstoque.add(txtQuantidadeEstoque);
                frameEstoque.add(lblLocalizacaoEstoque);
                frameEstoque.add(txtLocalizacaoEstoque);
                frameEstoque.add(lblResponsavelEstoque);
                frameEstoque.add(txtResponsavelEstoque);
                frameEstoque.add(btnSalvarEstoque);

                //SALVA O CADASTRO DO ESTOQUE FEITO PELO USUARIO
                btnSalvarEstoque.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        String tipoEstoque = txtTipoEstoque.getText();
                        int quantidadeEstoque = Integer.parseInt(txtQuantidadeEstoque.getText());
                        String localizacaoEstoque = txtLocalizacaoEstoque.getText();
                        String responsavelEstoque = txtResponsavelEstoque.getText();
                        Estoque estoque = new Estoque(tipoEstoque, quantidadeEstoque, localizacaoEstoque, responsavelEstoque);
                        estoques.add(estoque);
                        //SALVA O ESTOQUE FEITO PELO USUARIO
                        JOptionPane.showMessageDialog(frameEstoque, "Estoque cadastrado com sucesso!\n" +
                                "Tipo: " + estoque.getTipo() + "\n" +
                                "Quantidade: " + estoque.getQuantidade() + "\n" +
                                "Localização: " + estoque.getLocalizacao() + "\n" +
                                "Responsável: " + estoque.getResponsavel());
                        frameEstoque.dispose();
                    }
                });
                frameEstoque.setLocationRelativeTo(null);
                frameEstoque.setVisible(true);
            }
        });

        //CADASTRO DE CATEGORIAS
        btnCategoria.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frameCategoria = new JFrame("Cadastro de Categoria");
                frameCategoria.setSize(500, 300);
                frameCategoria.setLayout(new GridLayout(2, 2));

                JLabel lblTipoCategoria = new JLabel("Tipo da Categoria do produto:");
                JTextField txtTipoCategoria = new JTextField();
                JButton btnSalvarCategoria = new JButton("Salvar Categoria");

                frameCategoria.add(lblTipoCategoria);
                frameCategoria.add(txtTipoCategoria);
                frameCategoria.add(btnSalvarCategoria);

                //SALVA O CADASTRO DA CATEGORIA PELO USUARIO
                btnSalvarCategoria.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        String tipoCategoria = txtTipoCategoria.getText();
                        categoria categoria = new categoria(tipoCategoria);
                        categorias.add(categoria);

                        //EXIBE A CATEGORIA CADASTRADA
                        JOptionPane.showMessageDialog(frameCategoria, "Categoria do produto cadastrada com sucesso!\n" +
                                "Nome: " + categoria.getTipo());
                        frameCategoria.dispose();
                    }
                });
                frameCategoria.setLocationRelativeTo(null);
                frameCategoria.setVisible(true);
            }
        });

        //CADASTRO DE PROMOCAO
        btnPromocao.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame framePromocao = new JFrame("Cadastro de Promoção");
                framePromocao.setSize(300, 400);
                framePromocao.setLayout(new GridLayout(4, 2));

                //USUÁRIO INSERE AS INFORMAÇÕES
                JLabel lblTipoPromocao = new JLabel("Tipo da Promoção:");
                JTextField txtTipoPromocao = new JTextField();
                JLabel lblProdutoPromocao = new JLabel("Produto da Promoção:");
                JTextField txtProdutoPromocao = new JTextField();
                JLabel lblNumeroDoPedidoPromocao = new JLabel("Numero do Pedido");
                JTextField txtNumeroDoPedidPromocao = new JTextField();
                JButton btnSalvarPromocao = new JButton("Salvar Promoção");

                framePromocao.add(lblTipoPromocao);
                framePromocao.add(txtTipoPromocao);
                framePromocao.add(lblProdutoPromocao);
                framePromocao.add(txtProdutoPromocao);
                framePromocao.add(lblNumeroDoPedidoPromocao);
                framePromocao.add(txtNumeroDoPedidPromocao);
                framePromocao.add(btnSalvarPromocao);

                //SALVA A PROMOCAO
                btnSalvarPromocao.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        String TipoPromocao = txtTipoPromocao.getText();
                        String ProdutoPromocao = txtProdutoPromocao.getText();
                        double NumeroDoPedidoPromocao = Double.parseDouble(txtNumeroDoPedidPromocao.getText());

                        System.out.println("Tipo de Promoção: " + TipoPromocao);
                        System.out.println("Produto da Promoção: " + ProdutoPromocao);
                        System.out.println("Número do Pedido da Promoção: " + NumeroDoPedidoPromocao);


                        Promocao promocao = new Promocao(TipoPromocao, ProdutoPromocao, NumeroDoPedidoPromocao);
                        promocoes.add(promocao);

                        //EXIBE A PROMOCAO CADASTRADA
                        JOptionPane.showMessageDialog(framePromocao, "Promoção cadastrada com sucesso!\n" +
                                "Tipo: " + promocao.getTipo() + "\n" +
                                "Produto:  " + promocao.getProduto() + "\n" +
                                "Numero do Pedido: " + promocao.getNumeroDoPedido());
                        framePromocao.dispose();
                    }
                });
                framePromocao.setLocationRelativeTo(null);
                framePromocao.setVisible(true);
            }
        });

        //CADASTRO DE FORMA DE PAGAMENTO
        btnFormaPagamento.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frameFormaPagamento = new JFrame("Cadastro de Forma de Pagamento");
                frameFormaPagamento.setSize(300, 400);
                frameFormaPagamento.setLayout(new GridLayout(3, 2));

                //USUÁRIO INSERE AS INFORMAÇÕES
                JLabel lblTipoPagamento = new JLabel("Tipo de Pagamento : ");
                JTextField txtTipoPagamento = new JTextField();
                JLabel lblNumeroDoPedido = new JLabel("Numero do Pedido : ");
                JTextField txtNumeroDoPedido = new JTextField();
                JButton btnSalvarFormaPagamento = new JButton("Salvar Forma de Pagamento");

                frameFormaPagamento.add(lblTipoPagamento);
                frameFormaPagamento.add(txtTipoPagamento);
                frameFormaPagamento.add(lblNumeroDoPedido);
                frameFormaPagamento.add(txtNumeroDoPedido);
                frameFormaPagamento.add(btnSalvarFormaPagamento);

                //SALVA O CADASTRO DA FORMA DE PAGAMENTO PELO USUARIO
                btnSalvarFormaPagamento.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        String tipoPagamento = txtTipoPagamento.getText();
                        FormaPagamento formaPag = new FormaPagamento(tipoPagamento);
                        formasPagamento.add(formaPag);

                        //EXIBE A FORMA DE PAGAMENTO
                        JOptionPane.showMessageDialog(frameFormaPagamento, "Forma de Pagamento cadastrada com sucesso!\n" +
                                "Forma: " + formaPag.getTipo());
                        frameFormaPagamento.dispose();
                    }
                });
                frameFormaPagamento.setLocationRelativeTo(null);
                frameFormaPagamento.setVisible(true);
            }
        });

        //CADASTRO DE COLABORADOR
        btnColaborador.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frameColaborador = new JFrame("Cadastro de Colaborador");
                frameColaborador.setSize(300, 400);
                frameColaborador.setLayout(new GridLayout(5, 2));

                //USUÁRIO INSERE AS INFORMAÇÕES
                JLabel lblNomeColaborador = new JLabel("Nome do Colaborador:");
                JTextField txtNomeColaborador = new JTextField();
                JLabel lblEmailColaborador = new JLabel("Email do Colaborador:");
                JTextField txtEmailColaborador = new JTextField();
                JLabel lblTelefoneColaborador = new JLabel("Telefone do Colaborador:");
                JTextField txtTelefoneColaborador = new JTextField();
                JLabel lblNivelColaborador = new JLabel("Nível do Colaborador:");
                JTextField txtNivelColaborador = new JTextField();
                JButton btnSalvarColaborador = new JButton("Salvar Colaborador");
                JButton btnVincularCategoria = new JButton("Vincular Categoria ao Produto");
                mainFrame.add(btnVincularCategoria);


                frameColaborador.add(lblNomeColaborador);
                frameColaborador.add(txtNomeColaborador);
                frameColaborador.add(lblEmailColaborador);
                frameColaborador.add(txtEmailColaborador);
                frameColaborador.add(lblTelefoneColaborador);
                frameColaborador.add(txtTelefoneColaborador);
                frameColaborador.add(lblNivelColaborador);
                frameColaborador.add(txtNivelColaborador);
                frameColaborador.add(new JLabel());
                frameColaborador.add(btnSalvarColaborador);

                // Salva o cadastro do colaborador feito pelo usuário
                btnSalvarColaborador.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        String nomeColaborador = txtNomeColaborador.getText();
                        String emailColaborador = txtEmailColaborador.getText();
                        String telefoneColaborador = txtTelefoneColaborador.getText();
                        String nivelColaborador = txtNivelColaborador.getText();
                        Colaborador colaborador = new Colaborador(nomeColaborador, emailColaborador, telefoneColaborador, nivelColaborador);
                        colaboradores.add(colaborador);

                        // Exibe o colaborador cadastrado
                        JOptionPane.showMessageDialog(frameColaborador, "Colaborador cadastrado com sucesso!\n" +
                                "Nome: " + colaborador.getNome() + "\n" +
                                "Email: " + colaborador.getEmail() + "\n" +
                                "Telefone: " + colaborador.getTelefone() + "\n" +
                                "Nível: " + colaborador.getNivel());
                        frameColaborador.dispose();
                    }
                });
                frameColaborador.setLocationRelativeTo(null);
                frameColaborador.setVisible(true);
            }
        });

        //CADASTRO DE CLIENTE
        btnCliente.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frameCliente = new JFrame("Cadastro de Cliente");
                frameCliente.setSize(300, 400);
                frameCliente.setLayout(new GridLayout(7, 2));

                //USUÁRIO INSERE AS INFORMAÇÕES
                JLabel lblNomeCliente = new JLabel("Nome do Cliente:");
                JTextField txtNomeCliente = new JTextField();
                JLabel lblEmailCliente = new JLabel("Email do Cliente:");
                JTextField txtEmailCliente = new JTextField();
                JLabel lblCPFCliente = new JLabel("CPF do Cliente:");
                JTextField txtCPFCliente = new JTextField();
                JRadioButton rbGenerico = new JRadioButton("Cliente Genérico");
                JRadioButton rbPremium = new JRadioButton("Cliente Premium");
                ButtonGroup group = new ButtonGroup();
                group.add(rbGenerico);
                group.add(rbPremium);
                JButton btnSalvarCliente = new JButton("Salvar Cliente");

                frameCliente.add(lblNomeCliente);
                frameCliente.add(txtNomeCliente);
                frameCliente.add(lblEmailCliente);
                frameCliente.add(txtEmailCliente);
                frameCliente.add(lblCPFCliente);
                frameCliente.add(txtCPFCliente);
                frameCliente.add(rbGenerico);
                frameCliente.add(rbPremium);
                frameCliente.add(btnSalvarCliente);

                // SALVA O CADASTRO DO CLIENTE FEITO PELO USUARIO
                btnSalvarCliente.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        String nomeCliente = txtNomeCliente.getText();
                        String emailCliente = txtEmailCliente.getText();
                        String cpfCliente = txtCPFCliente.getText(); // Captura o CPF digitado

                        if (rbGenerico.isSelected()) {
                            Cliente cliente = new ClienteGenerico(nomeCliente, emailCliente, null, cpfCliente);
                            clientes.add(cliente);
                            // EXIBE O CLIENTE GENÉRICO CADASTRADO
                            JOptionPane.showMessageDialog(frameCliente, "Cliente Genérico cadastrado com sucesso!\n" +
                                    "Nome: " + cliente.getNome() + "\n" +
                                    "Email: " + cliente.getEmail() + "\n" +
                                    "CPF: " + cliente.getCpf());
                        } else if (rbPremium.isSelected()) {
                            Cliente cliente = new ClientePremium(nomeCliente, emailCliente, null, cpfCliente);
                            clientes.add(cliente);
                            // EXIBE O CLIENTE PREMIUM CADASTRADO
                            JOptionPane.showMessageDialog(frameCliente, "Cliente Premium cadastrado com sucesso!\n" +
                                    "Nome: " + cliente.getNome() + "\n" +
                                    "Email: " + cliente.getEmail() + "\n" +
                                    "CPF: " + cliente.getCpf());
                        } else {
                            JOptionPane.showMessageDialog(frameCliente, "Por favor, selecione o tipo de cliente.");
                            return;
                        }

                        frameCliente.dispose();
                    }
                });
                frameCliente.setLocationRelativeTo(null);
                frameCliente.setVisible(true);
            }
        });

        //CADASTRO DE PEDIDO
        btnPedido.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                JFrame framePedido = new JFrame("Cadastro de Pedido");
                framePedido.setSize(300, 400);
                framePedido.setLayout(new GridLayout(6, 2));

                //USUÁRIO INSERE AS INFORMAÇÕES
                JLabel lblNumeroPedido = new JLabel("Número do Pedido:");
                JTextField txtNumeroPedido = new JTextField();
                JLabel lblProdutoPedido = new JLabel("Produto:");
                JComboBox<Produto> cbProdutoPedido = new JComboBox<>(produtos.toArray(new Produto[0]));
                JLabel lblClientePedido = new JLabel("Cliente:");
                JComboBox<Cliente> cbClientePedido = new JComboBox<>(clientes.toArray(new Cliente[0]));
                JLabel lblQuantidadePedido = new JLabel("Quantidade:");
                JTextField txtQuantidadePedido = new JTextField();
                JLabel lblFormaPagamentoPedido = new JLabel("Forma de Pagamento:");
                JComboBox<FormaPagamento> cbFormaPagamentoPedido = new JComboBox<>(formasPagamento.toArray(new FormaPagamento[0]));
                JButton btnSalvarPedido = new JButton("Salvar Pedido");

                framePedido.add(lblNumeroPedido);
                framePedido.add(txtNumeroPedido);
                framePedido.add(lblProdutoPedido);
                framePedido.add(cbProdutoPedido);
                framePedido.add(lblClientePedido);
                framePedido.add(cbClientePedido);
                framePedido.add(lblQuantidadePedido);
                framePedido.add(txtQuantidadePedido);
                framePedido.add(lblFormaPagamentoPedido);
                framePedido.add(cbFormaPagamentoPedido);
                framePedido.add(btnSalvarPedido);

                // Exibir a janela
                framePedido.setLocationRelativeTo(null);
                framePedido.setVisible(true);

                // SALVA O CADASTRO DO PEDIDO
                btnSalvarPedido.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            // Obter os valores inseridos pelo usuário
                            int numeroPedido = Integer.parseInt(txtNumeroPedido.getText());
                            Produto produtoSelecionado = (Produto) cbProdutoPedido.getSelectedItem();
                            Cliente clienteSelecionado = (Cliente) cbClientePedido.getSelectedItem();
                            int quantidadePedido = Integer.parseInt(txtQuantidadePedido.getText());
                            FormaPagamento formaPagamentoSelecionada = (FormaPagamento) cbFormaPagamentoPedido.getSelectedItem();

                            System.out.println("Número do Pedido: " + numeroPedido);
                            System.out.println("Produto: " + produtoSelecionado);
                            System.out.println("Cliente: " + clienteSelecionado);
                            System.out.println("Quantidade: " + quantidadePedido);
                            System.out.println("Forma de Pagamento: " + formaPagamentoSelecionada);


                            // Criar um novo objeto Pedido
                            Pedido novoPedido = new Pedido(numeroPedido, produtoSelecionado, clienteSelecionado, quantidadePedido, formaPagamentoSelecionada);

                            // Aqui você pode salvar o novo pedido em uma lista de pedidos, por exemplo
                            pedidos.add(novoPedido);

                            // Exibir mensagem de sucesso
                            JOptionPane.showMessageDialog(null, "Pedido salvo com sucesso!");

                            // Limpar campos ou realizar outras ações necessárias após salvar o pedido
                            txtNumeroPedido.setText("");
                            txtQuantidadePedido.setText("");
                            // Limpar outros campos se necessário

                            // Você pode querer atualizar a interface ou fazer outras ações aqui
                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(null, "Por favor, insira um número válido.");
                        } catch (Exception ex) {
                            JOptionPane.showMessageDialog(null, "Ocorreu um erro ao salvar o pedido.");
                        }
                    }
                });
            }
        });

                //MOSTRAR PEDIDOS
                btnMostrarPedidos.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if (pedidos.isEmpty()) {
                            JOptionPane.showMessageDialog(mainFrame, "Não há pedidos cadastrados ainda.");
                        } else {
                            StringBuilder pedidosText = new StringBuilder();
                            for (Pedido pedido : pedidos) {
                                pedidosText.append("Número do Pedido: ").append(pedido.getNumeroPedido()).append("\n")
                                        .append("Produto: ").append(pedido.getProduto().getNome()).append("\n")
                                        .append("Cliente: ").append(pedido.getCliente().getNome()).append("\n")
                                        .append("Forma de Pagamento: ").append(pedido.getFormaDePagamento().getTipo()).append("\n\n");
                            }
                            JOptionPane.showMessageDialog(mainFrame, pedidosText.toString(), "Pedidos Cadastrados", JOptionPane.INFORMATION_MESSAGE);
                        }
                    }
                });

                //VINCULAR PROMOCAO AO PRODUTO
                AbstractButton btnVincularPromocao = null;
                btnVincularPromocao.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        JFrame frameVincularPromocao = new JFrame("Vincular Promoção ao Produto");
                        frameVincularPromocao.setSize(300, 400);
                        frameVincularPromocao.setLayout(new GridLayout(3, 2));

                        JLabel lblProduto = new JLabel("Produto:");
                        JComboBox<Produto> cbProduto = new JComboBox<>(produtos.toArray(new Produto[0]));
                        JLabel lblPromocao = new JLabel("Promoção:");
                        JComboBox<Promocao> cbPromocao = new JComboBox<>(promocoes.toArray(new Promocao[0]));
                        JButton btnVincular = new JButton("Vincular Promoção");

                        frameVincularPromocao.add(lblProduto);
                        frameVincularPromocao.add(cbProduto);
                        frameVincularPromocao.add(lblPromocao);
                        frameVincularPromocao.add(cbPromocao);
                        frameVincularPromocao.add(btnVincular);

                        //VINCULA A PROMOCAO AO PRODUTO
                        btnVincular.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e) {
                                Produto produto = (Produto) cbProduto.getSelectedItem();
                                double promocao = (double) cbPromocao.getSelectedItem();
                                JOptionPane.showMessageDialog(frameVincularPromocao, "Erro ao vincular promoção ao produto.");
                                frameVincularPromocao.dispose();
                            }
                        });
                        frameVincularPromocao.setLocationRelativeTo(null);
                        frameVincularPromocao.setVisible(true);
                    }

                });
            }
        }