import javax.swing.*;

public class Pedido {
    private Produto produto;
    private Cliente cliente;
    private FormaPagamento formaDePagamento;  // Alterado de String para FormaPagamento
    private Colaborador colaborador;
    private int numeroPedido;  // Renomeado para seguir convenção JavaBeans

    public Pedido(Produto produto, Cliente cliente, FormaPagamento formaDePagamento, Colaborador colaborador, int numeroPedido) {
        this.produto = produto;
        this.cliente = cliente;
        this.formaDePagamento = formaDePagamento;
        this.colaborador = colaborador;
        this.numeroPedido = numeroPedido;
    }

    // Construtor adicionado para o segundo caso específico
    public Pedido(int numeroPedido, Produto produtoPedido, Cliente clientePedido, int quantidadePedido, FormaPagamento formaPagamentoPedido) {
        this.numeroPedido = numeroPedido;
        this.produto = produtoPedido;
        this.cliente = clientePedido;
        this.formaDePagamento = formaPagamentoPedido;
    }

    public void vincularCategoriaProduto(categoria categoria) {
        if (produto != null) {
            produto.setCategoria(categoria);
            JOptionPane.showMessageDialog(null, "Categoria vinculada ao produto com sucesso!\n" +
                    "Produto: " + produto.getNome() + "\n" +
                    "Categoria: " + categoria.getTipo());
        } else {
            JOptionPane.showMessageDialog(null, "Erro ao vincular categoria ao produto.");
        }
    }

    public int getNumeroPedido() {
        return numeroPedido;
    }

    public void setNumeroPedido(int numeroPedido) {
        this.numeroPedido = numeroPedido;
    }

    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public FormaPagamento getFormaDePagamento() {
        return formaDePagamento;
    }

    public void setFormaDePagamento(FormaPagamento formaDePagamento) {
        this.formaDePagamento = formaDePagamento;
    }

    public Colaborador getColaborador() {
        return colaborador;
    }

    public void setColaborador(Colaborador colaborador) {
        this.colaborador = colaborador;
    }
}
