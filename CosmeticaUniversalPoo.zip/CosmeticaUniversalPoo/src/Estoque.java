public class Estoque {
    private String tipo;
    private int quantidade;
    private String localizacao;
    private String responsavel;

    public Estoque(String tipo, int quantidade, String localizacao, String responsavel) {
        this.tipo = tipo;
        this.quantidade = quantidade;
        this.localizacao = localizacao;
        this.responsavel = responsavel;
    }

    // Getters e Setters
    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public String getLocalizacao() {
        return localizacao;
    }

    public void setLocalizacao(String localizacao) {
        this.localizacao = localizacao;
    }

    public String getResponsavel() {
        return responsavel;
    }

    public void setResponsavel(String responsavel) {
        this.responsavel = responsavel;
    }
}
