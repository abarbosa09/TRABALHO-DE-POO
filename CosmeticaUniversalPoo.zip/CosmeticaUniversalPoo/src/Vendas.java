public class Vendas {
    private String tipo;
    private Produto produto;
    private int numeroDoPedido;
    private Cliente cliente;

    public Vendas(String tipo, Produto produto, int numeroDoPedido, Cliente cliente) {
        this.tipo = tipo;
        this.produto = produto;
        this.numeroDoPedido = numeroDoPedido;
        this.cliente = cliente;
    }

    // Getters e Setters
    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }

    public int getNumeroDoPedido() {
        return numeroDoPedido;
    }

    public void setNumeroDoPedido(int numeroDoPedido) {
        this.numeroDoPedido = numeroDoPedido;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
}
