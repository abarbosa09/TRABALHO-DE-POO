public class ClienteGenerico extends Cliente {
    public ClienteGenerico(String nome, String email, String telefone, String cpf) {
        super(nome, email, telefone, cpf); // Chama o construtor da superclasse Cliente
    }
}
