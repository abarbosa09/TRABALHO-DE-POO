class ClientePremium extends Cliente {
    private int nivelPremium;


    public ClientePremium(String nomeCliente, String emailCliente, String telefone, String cpfCliente) {
        super(nomeCliente, emailCliente, telefone, cpfCliente);
    }

    // Getter e setter para o atributo nivelPremium
    public int getNivelPremium() {
        return nivelPremium;
    }

    public void setNivelPremium(int nivelPremium) {
        this.nivelPremium = nivelPremium;
    }

    // Sobreescrita do método toString para incluir informações específicas do ClientePremium
    @Override
    public String toString() {
        return "ClientePremium{" +
                "nome='" + getNome() + '\'' +
                ", email='" + getEmail() + '\'' +
                ", telefone='" + getTelefone() + '\'' +
                ", cpf='" + getCpf() + '\'' +
                ", nivelPremium=" + nivelPremium +
                '}';
    }
}