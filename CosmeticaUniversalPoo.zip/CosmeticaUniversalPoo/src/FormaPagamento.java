public class FormaPagamento {
    private String tipo;
    private int numeroDoPedido;

    public FormaPagamento(String tipo) {
        this.tipo = tipo;
        this.numeroDoPedido = 0;  // Inicializando o número do pedido com 0 por padrão

    }
    public String toString() {
        return tipo;  // Para exibir o nome do produto no JComboBox
    }



    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getNumeroDoPedido() {
        return numeroDoPedido;
    }

    public void setNumeroDoPedido(int numeroDoPedido) {
        this.numeroDoPedido = numeroDoPedido;
    }
}
