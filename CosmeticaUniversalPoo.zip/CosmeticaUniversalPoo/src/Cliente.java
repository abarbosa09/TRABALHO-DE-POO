public class Cliente extends Pessoa {
    public Cliente(String nome, String email, String telefone, String cpf) {
        super(nome, email, telefone, cpf); // Chama o construtor da superclasse Pessoa
    }
    public String toString() {
        return getNome();  // Para exibir o nome do produto no JComboBox
    }
}
